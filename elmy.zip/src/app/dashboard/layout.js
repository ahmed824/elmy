
import DashBoardLayoutHelper from "../components/dashboard/DashBoardLayoutHelper";

export default function Dashboardlayout({ children }) {
  return <>{children}</>;
}
