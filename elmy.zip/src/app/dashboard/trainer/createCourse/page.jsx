import CourseCreationForm from "@/app/components/dashboard/CourseCreationForm";

export default function page() {
  return (
    <CourseCreationForm/>
  )
}
