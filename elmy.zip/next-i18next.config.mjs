export const i18n = {
  locales: ["en", "ar"],
  defaultLocale: "ar",
  localeDetection: false,
  ns: ["translation"],
  defaultNS: "translation",
};